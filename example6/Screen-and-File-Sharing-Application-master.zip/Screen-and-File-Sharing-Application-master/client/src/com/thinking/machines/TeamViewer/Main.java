package com.thinking.machines.TeamViewer;
import com.thinking.machines.TeamViewer.MainFrame.*;
public class Main
{
 public static void main(String gg[])
 {
  new ClientUI();
 }
}