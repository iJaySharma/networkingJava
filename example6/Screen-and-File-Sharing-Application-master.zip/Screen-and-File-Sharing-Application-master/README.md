# Screen-and-File-Sharing-Application
It's a application which can be used to control one system with another also it can be used to transfer files between two systems.

In order to use this application follow as belows:
1. Download zip file.
2. Extract them in 2 systems.
3. In one system move to server/src/com/thinking/machines/TeamViwer and open LaunchServer.bat file.
4. In other system move to client/src/com/thinking/machines/TeamViwer and open LaunchClient.bat file and enter the IP of server.
