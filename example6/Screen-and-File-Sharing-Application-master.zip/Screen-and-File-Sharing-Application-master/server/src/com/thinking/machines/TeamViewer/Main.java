package com.thinking.machines.TeamViewer;
import com.thinking.machines.TeamViewer.MainFrame.*;
public class Main
{
 public static void main(String gg[])
 {
  new ServerUI();
  /*try
  {
   new Server1();
  }catch(Exception e)
  {
  }*/
 }
}